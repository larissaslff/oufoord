package br.com.ourfood.ourfood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OurfoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
