package br.com.ourfood.ourfood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OurfoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(OurfoodApplication.class, args);
	}

}
